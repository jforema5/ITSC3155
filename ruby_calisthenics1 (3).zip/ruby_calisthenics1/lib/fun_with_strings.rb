module FunWithStrings
  
  
  
  def palindrome?
    # your code here
    
    if self.downcase.gsub(/[^a-z0-9]+/i, '') == self.downcase.gsub(/[^a-z0-9]+/i, '').reverse
      return true
    else 
      return false
    end
  
  end
  
  def count_words
    # your code here
    counter = Hash.new(0)
    words = self.downcase.gsub(/[\W]/,' ').split(' ')
    
    words.each { |x| counter[x] += 1 }
  
 return counter
  end
  
  
  def anagram_groups
    # your code here
    
    self.split.group_by{|i| i.downcase.each_char.sort}.values
  end
    
  
end

# make all the above functions available as instance methods on Strings:

class String
  include FunWithStrings
end
