# RubyHashes
# Part I
def array_2_hash emails, contacts
    
i = 0
if emails.empty?
    return contacts
else
    contacts.each do |key, value|
        contacts[key] = emails[i]
        i+=1
    end
end
return contacts
end
# Part II
def array2d_2_hash contact_info, contacts
    
    if emails.empty?
        return contacts
    else
    contacts["Bob Smith"][:email] = contact_info[0][0]
    contacts["Bob Smith"][:phone] = contact_info[0][1]
    contacts["Sally Field"][:email] = contact_info[1][0]
    contacts["Sally Field"][:phone] = contact_info[1][1]
end
end
return contacts
# Part III
def hash_2_array contacts
    # YOUR CODE HERE
end
